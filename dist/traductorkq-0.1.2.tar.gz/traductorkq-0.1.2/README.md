# Traductor

Programa para traducir palabras de Ingles a Espanol

## Instalacion

pip install traductorkq

## Forma de uso

traductorkq "hello"

hello -> hola